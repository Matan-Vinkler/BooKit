package com.example.BookitApp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterActivity extends AppCompatActivity {

    TextView linkTextView;
    private Button btn_register;
    EditText etUserName;
    EditText etEmail;
    EditText etPassword;
    EditText etConfirmPassword;
    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth=FirebaseAuth.getInstance();


        etUserName=(EditText) findViewById(R.id.etUserName);
        etEmail=(EditText) findViewById(R.id.etEmail);
        etPassword=(EditText) findViewById(R.id.etPassword);
        etConfirmPassword=(EditText) findViewById(R.id.etConfirmPassword);

        linkTextView= (TextView) findViewById(R.id.linktextview);
        linkTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(i);

                Toast.makeText(RegisterActivity.this,"Login page",Toast.LENGTH_LONG).show();
            }
        });

        btn_register=(Button) findViewById(R.id.btn_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (createuser()) {
                    openHomePage();
                }

            }

            public void openHomePage() {
                Intent intent= new Intent(RegisterActivity.this,HomePageActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }
    private boolean createuser() {
        String UserName= etUserName.getText().toString();
        String Email= etEmail.getText().toString();
        String Password= etPassword.getText().toString();
        String ConfirmPassword= etConfirmPassword.getText().toString();

        if (TextUtils.isEmpty(Email)) {
            etEmail.setError("Email cannot be empty");
            etEmail.requestFocus();
            return false;
        }
        else if (TextUtils.isEmpty(Password)) {
            etPassword.setError("Password cannot be empty");
            etPassword.requestFocus();
            return false;
        }
        else if (TextUtils.isEmpty(UserName)) {
            etUserName.setError("User name cannot be empty");
            etUserName.requestFocus();
            return false;
        }
        else if (TextUtils.isEmpty(ConfirmPassword)) {
            etConfirmPassword.setError("Confirm password name cannot be empty");
            etConfirmPassword.requestFocus();
            return false;
        }
        else {
            mAuth.createUserWithEmailAndPassword(Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(RegisterActivity.this, "User registered successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
                    }
                    else {
                        Toast.makeText(RegisterActivity.this, "Registration error:"+task.getException().getMessage() , Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
        return true;
    }

}