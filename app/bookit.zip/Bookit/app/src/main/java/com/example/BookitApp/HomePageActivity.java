package com.example.BookitApp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

public class HomePageActivity extends AppCompatActivity {

    Button btn_LogOut;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Fantasy"));
        tabLayout.addTab(tabLayout.newTab().setText("Action"));
        tabLayout.addTab(tabLayout.newTab().setText("Detective"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        final ViewPager viewPager =(ViewPager)findViewById(R.id.view_pager);
        TabsAdapter tabsAdapter = new TabsAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(tabsAdapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        btn_LogOut= findViewById(R.id.btn_LogOut);
        mAuth= FirebaseAuth.getInstance();

        btn_LogOut.setOnClickListener(view -> {
            mAuth.signOut();
            startActivity(new Intent(HomePageActivity.this,RegisterActivity.class));
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id= item.getItemId();
        if (id==R.id.horror) {
            Intent i=new Intent(HomePageActivity.this,Horror.class);
            startActivity(i);
            finish();
            return true;
        }
        if (id==R.id.fantasy) {
            Intent i=new Intent(HomePageActivity.this,Fantasy.class);
            startActivity(i);
            finish();
            return true;
        }
        if (id==R.id.action) {
            Intent i=new Intent(HomePageActivity.this,Action.class);
            startActivity(i);
            finish();
            return true;
        }
        if (id==R.id.detective) {
            Intent i=new Intent(HomePageActivity.this,Detective.class);
            startActivity(i);
            finish();
            return true;
        }
        if (id==R.id.young) {
            Intent i=new Intent(HomePageActivity.this,YoungAdult.class);
            startActivity(i);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
 class TabsAdapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;
    public TabsAdapter(FragmentManager fm, int NoofTabs){
        super(fm);
        this.mNumOfTabs = NoofTabs;
    }
    @Override
    public int getCount() {
        return mNumOfTabs;
    }
    @Override
    public Fragment getItem(int position){
        switch (position){
            case 0:
                FantasyGenreFragment fantasy = new FantasyGenreFragment();
                return fantasy;
            case 1:
                ActionGenreFragment action = new ActionGenreFragment();
                return action;
            case 2:
                DetectiveGenreFragment detective = new DetectiveGenreFragment();
                return detective;
            default:
                return null;
        }
    }
}